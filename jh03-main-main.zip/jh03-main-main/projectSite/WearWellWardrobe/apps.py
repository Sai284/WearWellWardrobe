from django.apps import AppConfig


class WearwellwardrobeConfig(AppConfig):
    name = 'WearWellWardrobe'
    default_auto_field = 'django.db.models.BigAutoField'
