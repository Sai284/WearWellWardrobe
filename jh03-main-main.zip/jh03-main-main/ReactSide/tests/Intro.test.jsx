import React from 'react';
import { describe, it, expect, vi } from 'vitest';
import { render, screen, act } from '@testing-library/react';
import Intro from '../src/components/Intro.jsx';

describe('Intro component', () => {
  it('renders the image initially', () => {
    render(<Intro />);
    const image = screen.getByAltText(/intro/i);
    expect(image).toBeInTheDocument();
  });

  it('removes the image and adds fade-out class after 2 seconds', () => {
    vi.useFakeTimers();
    const { container } = render(<Intro />);

    // 1) Image is initially present
    expect(screen.getByAltText(/intro/i)).toBeInTheDocument();

    // 2) Advance time by 2 seconds
    act(() => {
      vi.advanceTimersByTime(2000);
    });

    // 3) React has processed the effect
    expect(screen.queryByAltText(/intro/i)).toBeNull();
    expect(container.querySelector('.intro-container').classList.contains('fade-out')).toBe(true);
  });
});