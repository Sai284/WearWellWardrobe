import React from 'react';
import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router-dom';
import BurgerMenu from '../src/components/BurgerMenu.jsx';

describe('BurgerMenu', () => {
  it('renders the burger icon and is closed by default', () => {
    const { container } = render(
      <MemoryRouter>
        <BurgerMenu />
      </MemoryRouter>
    );

    // Check that the burger icon is in the document
    const burgerLines = container.querySelectorAll('.burger-line');
    expect(burgerLines.length).toBe(3);

    // Side menu should not have 'show' class initially
    const sideMenu = container.querySelector('.side-menu');
    expect(sideMenu).not.toHaveClass('show');

    // Overlay shouldn't exist (isOpen = false)
    expect(container.querySelector('.menu-overlay')).toBeNull();
  });

  it('opens the menu when the burger icon is clicked', async () => {
    const user = userEvent.setup();
    const { container } = render(
      <MemoryRouter>
        <BurgerMenu />
      </MemoryRouter>
    );

    // Click the burger icon
    const burgerIcon = container.querySelector('.burger-icon');
    await user.click(burgerIcon);

    // Side menu should have 'show' class
    const sideMenu = container.querySelector('.side-menu');
    expect(sideMenu).toHaveClass('show');

    // Overlay should appear
    const overlay = container.querySelector('.menu-overlay');
    expect(overlay).toBeInTheDocument();

    // Burger lines should have 'open' class
    const burgerLines = container.querySelectorAll('.burger-line.open');
    expect(burgerLines.length).toBe(3);
  });

  it('closes the menu when the overlay is clicked', async () => {
    const user = userEvent.setup();
    const { container } = render(
      <MemoryRouter>
        <BurgerMenu />
      </MemoryRouter>
    );

    // Open the menu
    await user.click(container.querySelector('.burger-icon'));

    // Click the overlay
    const overlay = container.querySelector('.menu-overlay');
    await user.click(overlay);

    // Menu should be closed again
    const sideMenu = container.querySelector('.side-menu');
    expect(sideMenu).not.toHaveClass('show');
    expect(container.querySelector('.menu-overlay')).toBeNull();
  });

  it('closes the menu when a link is clicked', async () => {
    const user = userEvent.setup();
    const { container } = render(
      <MemoryRouter>
        <BurgerMenu />
      </MemoryRouter>
    );

    // Open the menu
    await user.click(container.querySelector('.burger-icon'));

    // Select the link by its href
    const accessLink = container.querySelector('a[href="/access"]');
    expect(accessLink).toBeInTheDocument();

    // Click the link
    await user.click(accessLink);

    // Side menu should no longer have 'show' class
    const sideMenu = container.querySelector('.side-menu');
    expect(sideMenu).not.toHaveClass('show');
  });

  it('renders all expected links', () => {
    const { container } = render(
      <MemoryRouter>
        <BurgerMenu />
      </MemoryRouter>
    );

    // Instead of matching text, we check hrefs
    const expectedHrefs = ['/access', '/maintain', '/storage', '/adapt', '/disposal'];

    expectedHrefs.forEach((href) => {
      const link = container.querySelector(`a[href="${href}"]`);
      expect(link).toBeInTheDocument();
    });
  });
});
