import React from 'react';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import Disposal from '../src/pages/Disposal.jsx';

describe('Disposal component', () => {
  // Mock the global fetch in each test
  beforeEach(() => {
    global.fetch = vi.fn();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('displays "Loading records..." while fetching data', async () => {
    // First fetch -> items
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [],
    });
    // Second fetch -> categories
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [],
    });

    render(
      <MemoryRouter>
        <Disposal />
      </MemoryRouter>
    );

    // Initially, it shows "Loading records..."
    expect(screen.getByText(/loading records\.\.\./i)).toBeInTheDocument();

    // Wait for fetch to complete
    await waitFor(() => {
      // categories array is empty => heading is "Not Found"
      expect(screen.getByRole('heading', { name: /not found/i })).toBeInTheDocument();
    });
  });

  it('always renders the "Unsure" link', async () => {
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [],
    });
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [],
    });

    render(
      <MemoryRouter>
        <Disposal />
      </MemoryRouter>
    );

    // The link is rendered unconditionally
    const unsureLink = screen.getByRole('link', { name: /unsure/i });
    expect(unsureLink).toBeInTheDocument();
    expect(unsureLink).toHaveAttribute('href', '/DisposalForm/0');
  });

  it('displays "No access options available." if category=5 has no matching records', async () => {
    // Items: none with category=5
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [
        { page_id: 100, title: 'Other Category Item', category: 2 },
      ],
    });
    // categories: includes category=5 => "Disposal"
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [
        { ID: 5, name: 'Disposal' },
        { ID: 2, name: 'Other' },
      ],
    });

    render(
      <MemoryRouter>
        <Disposal />
      </MemoryRouter>
    );

    // After fetch, heading should be "Disposal"
    await waitFor(() => {
      expect(screen.getByRole('heading', { name: /disposal/i })).toBeInTheDocument();
    });

    expect(screen.getByText(/no access options available/i)).toBeInTheDocument();
  });

  it('displays correct links if category=5 has records', async () => {
    // Items with category=5
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [
        { page_id: 101, title: 'Donate Clothes', category: 5 },
        { page_id: 102, title: 'Recycle Textiles', category: 5 },
        { page_id: 200, title: 'Random Item', category: 2 },
      ],
    });
    // categories: includes ID=5 => "Disposal"
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [
        { ID: 5, name: 'Disposal' },
        { ID: 2, name: 'Other' },
      ],
    });

    render(
      <MemoryRouter>
        <Disposal />
      </MemoryRouter>
    );

    // Wait for fetch to finish
    await waitFor(() => {
      expect(screen.getByRole('heading', { name: /disposal/i })).toBeInTheDocument();
    });

    // See links for the category=5 items
    expect(screen.getByRole('link', { name: /donate clothes/i })).toBeInTheDocument();
    expect(screen.getByRole('link', { name: /recycle textiles/i })).toBeInTheDocument();

    // The item with category=2 is NOT shown
    expect(screen.queryByRole('link', { name: /random item/i })).not.toBeInTheDocument();
  });

  it('shows "Not Found" if categories do not include ID=5', async () => {
    // Items can be anything, the main check is that category ID=5 is missing
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [
        { page_id: 999, title: 'Discard Clothing Properly', category: 5 },
      ],
    });
    // categories: missing ID=5
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [
        { ID: 1, name: 'Access' },
        { ID: 2, name: 'Other' },
      ],
    });

    render(
      <MemoryRouter>
        <Disposal />
      </MemoryRouter>
    );

    // After fetch, heading is "Not Found" since ID=5 doesn't exist in categories
    await waitFor(() => {
      expect(screen.getByRole('heading', { name: /not found/i })).toBeInTheDocument();
    });
  });

});
