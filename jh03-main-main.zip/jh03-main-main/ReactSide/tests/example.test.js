import { describe, it, expect } from 'vitest'

describe('Example test', () => {
  it('works', () => {
    expect(true).toBe(true)
  })
})
