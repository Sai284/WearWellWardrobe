import React from 'react';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import Storage from '../src/pages/Storage.jsx';

describe('Storage component', () => {
  // Mock fetch in each test
  beforeEach(() => {
    global.fetch = vi.fn();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('displays "Loading records..." while fetching data', async () => {
    // First fetch -> items
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [],
    });
    // Second fetch -> categories
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [],
    });

    render(
      <MemoryRouter>
        <Storage />
      </MemoryRouter>
    );

    // Initially: "Loading records..."
    expect(screen.getByText(/loading records\.\.\./i)).toBeInTheDocument();

    // Wait for fetch to complete
    await waitFor(() => {
      // categories array is empty => heading is "Not Found"
      expect(screen.getByRole('heading', { name: /not found/i })).toBeInTheDocument();
    });
  });

  it('displays "No access options available." if category=2 has no matching records', async () => {
    // Items that don't include category=2
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [
        { page_id: 999, title: 'Random Item', category: 1 },
      ],
    });
    // categories: includes category=2 => "Storage"
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [
        { ID: 2, name: 'Storage' },
        { ID: 1, name: 'Access' },
      ],
    });

    render(
      <MemoryRouter>
        <Storage />
      </MemoryRouter>
    );

    // After fetch, heading is "Storage"
    await waitFor(() => {
      expect(screen.getByRole('heading', { name: /storage/i })).toBeInTheDocument();
    });

    // Because no record has category=2, there are "No access options available."
    expect(screen.getByText(/no access options available/i)).toBeInTheDocument();
  });

  it('displays correct links if category=2 has records', async () => {
    // Items with category=2
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [
        { page_id: 101, title: 'Vacuum Pack Storage', category: 2 },
        { page_id: 102, title: 'Moth Prevention Tips', category: 2 },
        { page_id: 300, title: 'Other Category', category: 1 },
      ],
    });
    // categories: includes ID=2 => "Storage"
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [
        { ID: 2, name: 'Storage' },
        { ID: 1, name: 'Access' },
      ],
    });

    render(
      <MemoryRouter>
        <Storage />
      </MemoryRouter>
    );

    // Wait for fetch to finish
    await waitFor(() => {
      expect(screen.getByRole('heading', { name: /storage/i })).toBeInTheDocument();
    });

    // The two records in category=2
    expect(screen.getByRole('link', { name: /vacuum pack storage/i })).toBeInTheDocument();
    expect(screen.getByRole('link', { name: /moth prevention tips/i })).toBeInTheDocument();

    // The item with category=1 should NOT appear
    expect(screen.queryByRole('link', { name: /other category/i })).not.toBeInTheDocument();
  });

  it('shows "Not Found" if categories do not include ID=2', async () => {
    // Items can be anything
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [
        { page_id: 999, title: 'Long-Term Wardrobe Storage', category: 2 },
      ],
    });
    // categories: missing ID=2
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [
        { ID: 1, name: 'Access' },
      ],
    });

    render(
      <MemoryRouter>
        <Storage />
      </MemoryRouter>
    );

    // After fetch, heading is "Not Found" since ID=2 doesn't exist
    await waitFor(() => {
      expect(screen.getByRole('heading', { name: /not found/i })).toBeInTheDocument();
    });
  });

});
