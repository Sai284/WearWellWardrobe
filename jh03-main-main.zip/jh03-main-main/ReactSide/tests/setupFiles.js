
import { expect } from 'vitest';
import * as jestDomMatchers from '@testing-library/jest-dom/matchers';


//console.log('Vitest expect is:', expect);
//console.log('Jest-dom matchers is:', jestDomMatchers);


// extends Vitest's expect method with jest-dom's matchers
expect.extend(jestDomMatchers);
