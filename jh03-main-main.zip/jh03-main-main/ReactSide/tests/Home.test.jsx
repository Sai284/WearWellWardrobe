import React from 'react';
import { describe, it, expect, beforeEach, vi } from 'vitest';
import { render, screen, fireEvent, act} from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import Home from '../src/pages/Home.jsx';

//mock 'react-router-dom' to intercept useNavigate calls
const mockNavigate = vi.fn();
vi.mock('react-router-dom', async () => {
  const actual = await vi.importActual('react-router-dom');
  return {
    ...actual,
    useNavigate: () => mockNavigate,
  };
});

describe('Home component', () => {
  //before each test, this import useNavigate's mock again for inspection
  beforeEach(() => {
    mockNavigate.mockClear();
    vi.useFakeTimers();
  });

  it('renders the header "Home"', () => {
    render(
      <MemoryRouter>
        <Home />
      </MemoryRouter>
    );
    expect(screen.getByRole('heading', { name: /wear well wardrobe/i })).toBeInTheDocument();
  });

  it('renders the logo image', () => {
    render(
      <MemoryRouter>
        <Home />
      </MemoryRouter>
    );
    const logoImg = screen.getByAltText(/logo/i);
    expect(logoImg).toBeInTheDocument();
  });

  //List of triangles and their expected routes
  const triangles = [
    { className: 'top', route: '/access' },
    { className: 'lease', route: '/records/2' },
    { className: 'rent', route: '/records/3' },
    { className: 'share', route: '/records/4' },
    { className: 'top-right', route: '/maintain' },
    { className: 'wash', route: '/records/6' },
    { className: 'repair', route: '/records/7' },
    { className: 'bottom-right', route: '/storage' },
    { className: 'clear', route: '/records/9' },
    { className: 'pest', route: '/records/10' },
    { className: 'bottom-left', route: '/adapt' },
    { className: 'upcycle', route: '/records/13' },
    { className: 'downcycle', route: '/records/12' },
    { className: 'top-left', route: '/disposal' },
    { className: 'donate', route: '/records/18' },
    { className: 'pass', route: '/records/16' },
    { className: 'sell', route: '/records/15' },
  ];

  //Test each triangle in a loop
  triangles.forEach(({ className, route }) => {
    it(`clicking "${className}" triangle sets active and navigates to "${route}"`, async () => {
      vi.useFakeTimers();

      const { container } = render(
        <MemoryRouter>
          <Home />
        </MemoryRouter>
      );

      const triangle = container.querySelector(`.triangle.${className}`);

      fireEvent.click(triangle);


      expect(triangle).toBeInTheDocument();

      expect(triangle).toHaveClass('active');

      act(() => {
        vi.advanceTimersByTime(200);
      });

      expect(mockNavigate).toHaveBeenCalledWith(route);
    }, 10000);
  });
});
