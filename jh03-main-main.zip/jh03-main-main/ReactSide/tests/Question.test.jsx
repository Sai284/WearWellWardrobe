import React from 'react';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import Question from '../src/pages/Question.jsx'; // Adjust path if needed

describe('Question component', () => {
  // Create a small helper to render <Question /> with a given initialEntries
  function renderQuestion(initialPathState) {
    return render(
      <MemoryRouter initialEntries={initialPathState}>
        <Routes>
          <Route path="/question/:questionIndex" element={<Question />} />
          <Route path="/result" element={<h2>Mock Result Page</h2>} />
          <Route path="/question/:questionIndex" element={<h2>Mock Next Question</h2>} />
        </Routes>
      </MemoryRouter>
    );
  }

  it('shows "Invalid question index." if the index is out of range', () => {
    // The questions array has length 2, so valid indexes are 0 and 1
    // Pass questionIndex=999
    renderQuestion(['/question/999']);

    expect(screen.getByText(/invalid question index\./i)).toBeInTheDocument();
  });

  it('displays the first question (index=0) with its options', () => {
    renderQuestion(['/question/0']);

    // The first question is "How old are the clothes?"
    expect(screen.getByRole('heading', { level: 2 })).toHaveTextContent(/how old are the clothes\?/i);

    // The options: "New","1-2 years","2-5 years","5+ years"
    expect(screen.getByRole('button', { name: /new/i })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /1-2 years/i })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /2-5 years/i })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /5\+ years/i })).toBeInTheDocument();
  });

  it('navigates to the next question when an option is clicked (not the last question)', async () => {
    const user = userEvent.setup();
    const { getByRole, findByText } = renderQuestion(['/question/0']);

    // Click "New" on question 0
    const newButton = getByRole('button', { name: /new/i });
    await user.click(newButton);

    // Expect to see question index=1 now
    // The second question is "How worn are the clothes?"
    expect(await findByText(/how worn are the clothes\?/i)).toBeInTheDocument();
  });

  it('navigates to /result if on the last question and an option is clicked', async () => {
    // The last question is index=1 (since we have 2 questions: index=0, index=1)
    const user = userEvent.setup();
    const { getByRole, findByText } = renderQuestion(['/question/1']);

    // The second question is "How worn are the clothes?"
    expect(getByRole('heading', { level: 2 })).toHaveTextContent(/how worn are the clothes\?/i);

    // Click "New" or any other option
    const newButton = getByRole('button', { name: /new/i });
    await user.click(newButton);

    // Should see the mock result page
    expect(await findByText(/mock result page/i)).toBeInTheDocument();
  });

  it('reuses previous answers from location.state if provided', async () => {
    const user = userEvent.setup();
    // Suppose the user previously answered question 0 with "1-2 years"
    const previousAnswers = ["1-2 years", null]; // we have 2 questions total
    // We'll start on question=1 with those answers
    renderQuestion([
      {
        pathname: '/question/1',
        state: { answers: previousAnswers },
      },
    ]);

    // Confirm we see the second question
    expect(screen.getByText(/how worn are the clothes\?/i)).toBeInTheDocument();

    // Click "Slightly"
    const slightlyBtn = screen.getByRole('button', { name: /slightly/i });
    await user.click(slightlyBtn);

    // We should navigate to /result
    expect(await screen.findByText(/mock result page/i)).toBeInTheDocument();
  });

});
