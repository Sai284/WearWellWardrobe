import React from 'react';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import Adapt from '../src/pages/Adapt.jsx';

describe('Adapt component', () => {
  // Mock fetch in each test
  beforeEach(() => {
    global.fetch = vi.fn();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('displays "Loading records..." while fetching data', async () => {
    // First fetch -> items
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [],
    });
    // Second fetch -> categories
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [],
    });

    render(
      <MemoryRouter>
        <Adapt />
      </MemoryRouter>
    );

    // Initially: "Loading records..."
    expect(screen.getByText(/loading records\.\.\./i)).toBeInTheDocument();

    await waitFor(() => {
      expect(screen.getByRole('heading', { name: /not found/i })).toBeInTheDocument();
    });
  });

  it('displays "No access options available." if category=4 has no matching records', async () => {
    // First fetch -> items
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [
        { page_id: 999, title: 'Other Category Item', category: 2 },
      ],
    });
    // Second fetch -> categories: includes category=4 => "Adapt"
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [
        { ID: 4, name: 'Adapt' },
        { ID: 2, name: 'Other' },
      ],
    });

    render(
      <MemoryRouter>
        <Adapt />
      </MemoryRouter>
    );

    // After fetch, the heading is "Adapt"
    await waitFor(() => {
      expect(screen.getByRole('heading', { name: /adapt/i })).toBeInTheDocument();
    });

    // Because no record has category4, there are "No access options available."
    expect(screen.getByText(/no access options available/i)).toBeInTheDocument();
  });

  it('displays correct links if category=4 has records', async () => {
    // Mock items with category=4
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [
        { page_id: 101, title: 'Upcycle Jeans', category: 4 },
        { page_id: 102, title: 'Alter Dress', category: 4 },
        { page_id: 200, title: 'Other Category', category: 2 },
      ],
    });
    // Mock categories that include ID=4 => "Adapt"
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [
        { ID: 4, name: 'Adapt' },
        { ID: 2, name: 'Other' },
      ],
    });

    render(
      <MemoryRouter>
        <Adapt />
      </MemoryRouter>
    );

    // Waiting for fetch to complete
    await waitFor(() => {
      // Heading should be "Adapt"
      expect(screen.getByRole('heading', { name: /adapt/i })).toBeInTheDocument();
    });

    // The two records in category=4
    expect(screen.getByRole('link', { name: /upcycle jeans/i })).toBeInTheDocument();
    expect(screen.getByRole('link', { name: /alter dress/i })).toBeInTheDocument();

    // The record with category=2 should not appear
    expect(screen.queryByRole('link', { name: /other category/i })).not.toBeInTheDocument();
  });

  it('shows "Not Found" if categories do not include ID=4', async () => {
    // Items can be anything, looking for the fallback heading
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [
        { page_id: 999, title: 'Random Adapt Item', category: 4 },
      ],
    });
    // Categories have no ID=4
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [
        { ID: 1, name: 'Access' },
        { ID: 2, name: 'Other' },
      ],
    });

    render(
      <MemoryRouter>
        <Adapt />
      </MemoryRouter>
    );

    // Wait for the fetch to complete
    await waitFor(() => {
      // The heading should be "Not Found" because ID=4 doesn't exist
      expect(screen.getByRole('heading', { name: /not found/i })).toBeInTheDocument();
    });
  });

});
