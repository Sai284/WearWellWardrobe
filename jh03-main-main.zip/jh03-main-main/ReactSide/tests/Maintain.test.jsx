import React from 'react';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import Maintain from '../src/pages/Maintain.jsx';

describe('Maintain component', () => {
  // Mock the global fetch in each test
  beforeEach(() => {
    global.fetch = vi.fn();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('displays "Loading records..." while fetching data', async () => {
    // First fetch -> items
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [],
    });
    // Second fetch -> categories
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [],
    });

    render(
      <MemoryRouter>
        <Maintain />
      </MemoryRouter>
    );

    // Initially: "Loading records..."
    expect(screen.getByText(/loading records\.\.\./i)).toBeInTheDocument();

    // Wait for fetch to finish
    await waitFor(() => {
      // categories array is empty => heading is "Not Found"
      expect(screen.getByRole('heading', { name: /not found/i })).toBeInTheDocument();
    });
  });

  it('displays "No access options available." if category=3 has no matching records', async () => {
    // Items that don't include category=3
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [
        { page_id: 200, title: 'Random Item', category: 2 },
      ],
    });
    // categories: includes category=3 => "Maintain"
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [
        { ID: 3, name: 'Maintain' },
        { ID: 2, name: 'Other' },
      ],
    });

    render(
      <MemoryRouter>
        <Maintain />
      </MemoryRouter>
    );

    // After fetch, heading is "Maintain"
    await waitFor(() => {
      expect(screen.getByRole('heading', { name: /maintain/i })).toBeInTheDocument();
    });

    // Because no record has category=3, we see "No access options available."
    expect(screen.getByText(/no access options available/i)).toBeInTheDocument();
  });

  it('displays correct links if category=3 has records', async () => {
    // Items with category=3
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [
        { page_id: 101, title: 'Wash Clothes Properly', category: 3 },
        { page_id: 102, title: 'Repair Damaged Seams', category: 3 },
        { page_id: 300, title: 'Other Category Item', category: 2 },
      ],
    });
    // categories: includes ID=3 => "Maintain"
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [
        { ID: 3, name: 'Maintain' },
        { ID: 2, name: 'Other' },
      ],
    });

    render(
      <MemoryRouter>
        <Maintain />
      </MemoryRouter>
    );

    // Wait for fetch to complete
    await waitFor(() => {
      expect(screen.getByRole('heading', { name: /maintain/i })).toBeInTheDocument();
    });

    // The two records in category=3
    expect(screen.getByRole('link', { name: /wash clothes properly/i })).toBeInTheDocument();
    expect(screen.getByRole('link', { name: /repair damaged seams/i })).toBeInTheDocument();

    // The item with category=2 should NOT appear
    expect(screen.queryByRole('link', { name: /other category item/i })).not.toBeInTheDocument();
  });

  it('shows "Not Found" if categories do not include ID=3', async () => {
    // Items can be anything
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [
        { page_id: 999, title: 'Care for Delicate Fabrics', category: 3 },
      ],
    });
    // categories: missing ID=3
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [
        { ID: 2, name: 'Other' },
      ],
    });

    render(
      <MemoryRouter>
        <Maintain />
      </MemoryRouter>
    );

    // After fetch, heading is "Not Found" since ID=3 doesn't exist in categories
    await waitFor(() => {
      expect(screen.getByRole('heading', { name: /not found/i })).toBeInTheDocument();
    });
  });

});
