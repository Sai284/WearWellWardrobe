import React from 'react';
import { describe, it, expect, beforeEach, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import {MemoryRouter,Routes,Route,useLocation,useNavigate,} from 'react-router-dom';
import AccessForm from '../src/pages/AccessForm.jsx';

//define the same questions array
const questions = [
  { question: "Do you really need it?", options: ["Yes", "No"] },
  { question: "Do you need it for just one occasion?", options: ["Yes", "No"] },
  { question: "Could you purchase this item second-hand?", options: ["Yes", "No"] },
  { question: "Can you shop in person?", options: ["Yes", "No"] },
];

describe('AccessForm', () => {
  //mock console.log to keep output clean
  beforeEach(() => {
    vi.spyOn(console, 'log').mockImplementation(() => {});
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('renders "Invalid question index." if param is out of range', () => {
    // render with /AccessForm/999 which is beyond the questions array length
    render(
      <MemoryRouter initialEntries={['/AccessForm/999']}>
        <Routes>
          <Route path="/AccessForm/:questionIndex" element={<AccessForm />} />
        </Routes>
      </MemoryRouter>
    );

    expect(screen.getByText(/Invalid question index\./i)).toBeInTheDocument();
  });

  it('displays the correct question and options when questionIndex=0', () => {
    render(
      <MemoryRouter initialEntries={['/AccessForm/0']}>
        <Routes>
          <Route path="/AccessForm/:questionIndex" element={<AccessForm />} />
        </Routes>
      </MemoryRouter>
    );

    // The first question is "Do you really need it?"
    expect(screen.getByRole('heading', { level: 2 })).toHaveTextContent(
      /do you really need it\?/i
    );

    expect(screen.getByRole('button', { name: /yes/i })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /no/i })).toBeInTheDocument();
  });

  it('navigates to next question when an option is clicked (not final question)', async () => {
    // spy on useNavigate calls by wrapping the app in a custom route

    // render questionIndex=0
    render(
      <MemoryRouter initialEntries={['/AccessForm/0']}>
        <Routes>
          <Route path="/AccessForm/:questionIndex" element={<AccessForm />} />
          <Route
            path="/AccessForm/:questionIndex"
            element={<h2>Mock Next Question</h2>}
          />
          <Route path="/AccessResult" element={<h2>Mock Result Page</h2>} />
        </Routes>
      </MemoryRouter>
    );

    // Click "Yes"
    const yesButton = screen.getByRole('button', { name: /yes/i });
    await userEvent.click(yesButton);

    expect(
      screen.getByText(/do you need it for just one occasion\?/i)
    ).toBeInTheDocument();
  });

  it('navigates to /AccessResult if on the final question and an option is clicked', async () => {
    render(
      <MemoryRouter initialEntries={[`/AccessForm/${questions.length - 1}`]}>
        <Routes>
          <Route path="/AccessForm/:questionIndex" element={<AccessForm />} />
          <Route path="/AccessResult" element={<h2>Mock Result Page</h2>} />
        </Routes>
      </MemoryRouter>
    );

    expect(
      screen.getByText(/can you shop in person\?/i)
    ).toBeInTheDocument();

    const noButton = screen.getByRole('button', { name: /no/i });
    await userEvent.click(noButton);

    expect(screen.getByText(/mock result page/i)).toBeInTheDocument();
  });

  it('reuses previous answers from location.state if provided', async () => {
    // Suppose the user previously answered question 0 with "No"
    // pass that in location.state
    const previousAnswers = ["No", null, null, null];

    render(
      <MemoryRouter
        initialEntries={[
          {
            pathname: '/AccessForm/1', // we’re on question 1
            state: { answers: previousAnswers },
          },
        ]}
      >
        <Routes>
          <Route path="/AccessForm/:questionIndex" element={<AccessForm />} />
          <Route path="/AccessResult" element={<h2>Mock Result Page</h2>} />
        </Routes>
      </MemoryRouter>
    );

    // The second question is "Do you need it for just one occasion?"
    expect(
      screen.getByText(/do you need it for just one occasion\?/i)
    ).toBeInTheDocument();

    // If "Yes"
    const yesButton = screen.getByRole('button', { name: /yes/i });
    await userEvent.click(yesButton);

    // should see questionIndex=2: "Could you purchase this item second-hand?"
    expect(
      screen.getByText(/could you purchase this item second-hand\?/i)
    ).toBeInTheDocument();
  });

});
