import React from 'react';
import { describe, it, expect } from 'vitest';
import { render } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import Navbar from '../src/components/Navbar.jsx';

describe('Navbar', () => {
  it('applies "green" class for the "/" route', () => {
    const { container } = render(
      <MemoryRouter initialEntries={['/']}>
        <Navbar />
      </MemoryRouter>
    );
    const navBar = container.querySelector('#NavBar');
    expect(navBar).toHaveClass('green');
  });

  it('applies "green" class for the "/about" route', () => {
    const { container } = render(
      <MemoryRouter initialEntries={['/about']}>
        <Navbar />
      </MemoryRouter>
    );
    const navBar = container.querySelector('#NavBar');
    expect(navBar).toHaveClass('green');
  });

  it('applies "help" class if pathname includes "help"', () => {
    const { container } = render(
      <MemoryRouter initialEntries={['/help']} >
        <Navbar />
      </MemoryRouter>
    );
    const navBar = container.querySelector('#NavBar');
    expect(navBar).toHaveClass('help');
  });

  it('applies "access" class if pathname includes "access"', () => {
    const { container } = render(
      <MemoryRouter initialEntries={['/access']} >
        <Navbar />
      </MemoryRouter>
    );
    const navBar = container.querySelector('#NavBar');
    expect(navBar).toHaveClass('access');
  });

  it('applies "maintain" class if pathname includes "maintain"', () => {
    const { container } = render(
      <MemoryRouter initialEntries={['/maintain']} >
        <Navbar />
      </MemoryRouter>
    );
    const navBar = container.querySelector('#NavBar');
    expect(navBar).toHaveClass('maintain');
  });

  it('applies "storage" class if pathname includes "storage"', () => {
    const { container } = render(
      <MemoryRouter initialEntries={['/storage']} >
        <Navbar />
      </MemoryRouter>
    );
    const navBar = container.querySelector('#NavBar');
    expect(navBar).toHaveClass('storage');
  });

  it('applies "adapt" class if pathname includes "adapt"', () => {
    const { container } = render(
      <MemoryRouter initialEntries={['/adapt']} >
        <Navbar />
      </MemoryRouter>
    );
    const navBar = container.querySelector('#NavBar');
    expect(navBar).toHaveClass('adapt');
  });

  it('applies "disposal" class if pathname includes "disposal"', () => {
    const { container } = render(
      <MemoryRouter initialEntries={['/disposal']} >
        <Navbar />
      </MemoryRouter>
    );
    const navBar = container.querySelector('#NavBar');
    expect(navBar).toHaveClass('disposal');
  });

  it('retains last color if no path match occurs', () => {

    const { container } = render(
      <MemoryRouter initialEntries={['/unknownPath']} >
        <Navbar />
      </MemoryRouter>
    );
    const navBar = container.querySelector('#NavBar');

    expect(navBar.className).toBe('');
  });
});
