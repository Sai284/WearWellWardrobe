import React from 'react';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import Access from '../src/pages/Access.jsx';

describe('Access component', () => {
  // Mock the global fetch function in each test
  beforeEach(() => {
    global.fetch = vi.fn();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('displays loading message while fetching data', async () => {
    // First fetch call -> items
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [],
    });
    // Second fetch call -> categories
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [],
    });

    render(
      <MemoryRouter>
        <Access />
      </MemoryRouter>
    );

    expect(screen.getByText(/loading records.../i)).toBeInTheDocument();

    await waitFor(() => {
      expect(screen.getByRole('heading', { name: /not found/i })).toBeInTheDocument();
    });
  });

  it('displays "No access options available." if category=1 has no records', async () => {
    // First fetch -> items: empty array for category=1
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [
        // Some records, but none with category=1
        { page_id: 10, title: 'Other Category', category: 2 },
      ],
    });
    // Second fetch -> categories: includes category=1
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [
        { ID: 1, name: 'Access' },
        { ID: 2, name: 'Other' },
      ],
    });

    render(
      <MemoryRouter>
        <Access />
      </MemoryRouter>
    );

    await waitFor(() => {
      // Heading should be "Access" from category=1
      expect(screen.getByRole('heading', { name: /access/i })).toBeInTheDocument();
    });

    expect(screen.getByText(/no access options available/i)).toBeInTheDocument();
  });

  it('displays the correct links if category=1 has records', async () => {
    // Mock items that include category=1
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [
        { page_id: 101, title: 'Rent Clothing', category: 1 },
        { page_id: 102, title: 'Borrow From Friends', category: 1 },
        { page_id: 200, title: 'Other Category Item', category: 2 },
      ],
    });
    // Mock categories that include ID=1 => "Access"
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [
        { ID: 1, name: 'Access' },
        { ID: 2, name: 'Other' },
      ],
    });

    render(
      <MemoryRouter>
        <Access />
      </MemoryRouter>
    );

    // Waiting for the items and categories to load
    await waitFor(() => {
      expect(screen.getByRole('heading', { name: /access/i })).toBeInTheDocument();
    });

    expect(screen.getByRole('link', { name: /unsure/i })).toBeInTheDocument();

    // The two records in category=1
    expect(screen.getByRole('link', { name: /rent clothing/i })).toBeInTheDocument();
    expect(screen.getByRole('link', { name: /borrow from friends/i })).toBeInTheDocument();

    // The record with category=2 should NOT appear
    expect(screen.queryByRole('link', { name: /other category item/i })).not.toBeInTheDocument();
  });

  it('shows "Not Found" if categories do not include ID=1', async () => {
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [
        { page_id: 999, title: 'Random Access', category: 1 },
      ],
    });
    // Categories have no ID=1
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [
        { ID: 2, name: 'Other' },
      ],
    });

    render(
      <MemoryRouter>
        <Access />
      </MemoryRouter>
    );

    await waitFor(() => {
      // The heading should be "Not Found" because we can't find category ID=1
      expect(screen.getByRole('heading', { name: /not found/i })).toBeInTheDocument();
    });
  });

});
