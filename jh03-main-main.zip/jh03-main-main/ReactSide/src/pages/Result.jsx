import { useLocation } from "react-router-dom";
import { Link } from 'react-router-dom';
import { useState, useEffect } from "react";

function Result() {
    const location = useLocation();
    const answers = location.state?.answers || [];
    console.log("Received answers:", answers);
    const [outcome, setOutcome] = useState(null);

    useEffect(() => {
        let newOutcome = <div><Link to="/Donate" className="body-link">Donate</Link></div>
        console.log("Updating outcome based on answers...");
        if (answers.includes("1-2 years") && answers.includes("Moderately")) {
            newOutcome = <div><Link to="/Donate" className="body-link">Donate</Link></div>
        } else if (answers[0] == ("New") && answers[1] == ("New")) {
            newOutcome = <div><Link to="/Donate" className="body-link">Donate</Link></div>
        }

        setOutcome(newOutcome);
    }, [answers]);

    return (
        <div>
            <br />
            <br />
            <br />
            <br />
            <br />
            <p>This link should help you dispose of your clothing properly: {outcome}</p>
        </div>
    )
};

export default Result;