import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import './ActionPage.css';

function Help() {
  var [records, setRecords] = useState([]);
  const [showIntro, setShowIntro] = useState(true);
  var [categories, setCategories] = useState([]);
  var online = false;

  useEffect(() => {
    async function fetchData() {
      try { /*Try to fetch from localhost first */
        let response = await fetch("http://127.0.0.1:8000/api/items/");
        if (!response.ok) throw new Error("Localhost did not respond");
        let data = await response.json();
        setRecords(data);
    
    let catResponse = await fetch("http://127.0.0.1:8000/api/categories/");
    if(!catResponse.ok) throw new Error("Localhost didnt connect for categories");
    let catData = await catResponse.json();
    setCategories(catData);
    
      } catch (error) {
        console.log("Could not connect to localHost. Connecting to Main Site");
    
        try { /*If localhost failed, try python anywhere next */
          let response = await fetch("https://wearwellwardrobe.pythonanywhere.com/api/items/");
          if (!response.ok) throw new Error("Main Site did not respond");
          let data = await response.json();
      online = true; // Know that its from python anywhere for image fetching
          setRecords(data);

      let catResponse = await fetch("https://wearwellwardrobe.pythonanywhere.com/api/categories/");
      if(!catResponse.ok) throw new Error("Localhost didnt connect for categories");
      let catData = await catResponse.json();
      setCategories(catData);
      
        } catch (err) { /* both failed */
          console.log("Both API calls failed:", err);
        }
      }
    }
    fetchData();
  }, []);
  
  return (
    <div className="ActionPage-container">
      <h1 className="ActionPage-title">{categories.find(item => item.ID === 7)?.name || "Not Found"}</h1>
      <p className="ActionPage-description">
        Select any help options.
      </p>
  
      <div className="ActionPage-buttons">
        {records.length > 0 ? (
          records.filter(record => record.category === 7).length > 0 ? (
            records
              .filter(record => record.category === 7)
              .map(record => ( 
                <Link key={record.page_id} to={`/records/${record.page_id}`} className="ActionPage-button">
                  {record.title}
                </Link>
              ))
          ) : (
            <p className="ActionPage-description">No help options available.</p>
          )
        ) : (
          <p className="ActionPage-description">Loading records...</p>
        )}
      </div>
    </div>
  );  
}
export default Help;
