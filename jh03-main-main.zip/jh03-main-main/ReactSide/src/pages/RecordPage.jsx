import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import React, { useEffect, useState } from 'react';

var online = false;
function returnLink(original) {
    const ID = "https://";
    if (original.includes(ID)) {
        let points = [];
        let links = [];

        for (let c = 0; c <= original.length - ID.length; c++) {
            if (original.substring(c, c + ID.length) === ID && (c === 0 || original[c - 1] === " ")) {
                points.push(c);
            }
        }

        for (let cs of points) {
            let cl = "";
            let temp = original.substring(cs);
            let c = 0;

            while (c < temp.length && temp[c] !== " ") {
                cl += temp[c];
                c++;
            }
            links.push(cl);
        }
        return links;
    }
    return [];
}

function detectAndConvertLinks(text, replaceText = "") {
    let output = text;
    let links = returnLink(text);

    return links.length === 0
        ? text
        : text.split(new RegExp(`(${links.join("|")})`)).map((part, index) => 
            links.includes(part) 
                ? <a key={index} href={part} className="linksForContents">{replaceText || part}</a> 
                : part
        );
}

function RecordPage({ record }) {
	var [records, setRecords] = useState([]);
	const [showIntro, setShowIntro] = useState(true);
	var [categories, setCategories] = useState([]);
	var online = false;
  
	var URL = "";
	useEffect(() => {
    async function fetchData() {
      try { /*Try to fetch from localhost first */
        let response = await fetch("http://127.0.0.1:8000/api/items/");
        if (!response.ok) throw new Error("Localhost did not respond");
        let data = await response.json();
        setRecords(data);

      } catch (error) {
        console.log("Could not connect to localHost. Connecting to Main Site");
		
        try { /*If localhost failed, try python anywhere next */
          let response = await fetch("https://wearwellwardrobe.pythonanywhere.com/api/items/");
          if (!response.ok) throw new Error("Main Site did not respond");
          let data = await response.json();
		  online = true; // Know that its from python anywhere for image fetching
          setRecords(data);
		  
        } catch (err) { /* both failed */
          console.log("Both API calls failed:", err);
        }
      }
    }
    fetchData();
  }, []);
  
	if(online == false){
		 URL = record.img1 ? `http://127.0.0.1:8000${record.img1}` : "";
	}else{
		 URL = record.img1 ? `https://wearwellwardrobe.pythonanywhere.com${record.img1}` : "";		
	}

	if(record.displayStyle == 1 && record.img1 != ""){
		return (
			<div>
			  <h1>{record.title}</h1>
			  
			  <p>{detectAndConvertLinks(record.content1)}</p>
			  <p>{detectAndConvertLinks(record.content2)}</p>
			  <p>{detectAndConvertLinks(record.content3)}</p>
			  <p>{detectAndConvertLinks(record.content4)}</p>
			  {URL && <img className="recordImages" src={URL} alt="Record" />}
			</div>
		);		
	}else if(record.displayStyle == 2 && record.img1 != ""){
		return (
			<div>
			  <h1>{record.title}</h1>
			  {URL && <img className="recordImages" src={URL} alt="Record" />}
			  <p>{detectAndConvertLinks(record.content1)}</p>
			  <p>{detectAndConvertLinks(record.content2)}</p>
			  <p>{detectAndConvertLinks(record.content3)}</p>
			  <p>{detectAndConvertLinks(record.content4)}</p>
			  
			</div>
		);				
	}else if(record.displayStyle == 3 && record.img1 != ""){
		return (
			<div>
			  <h1>{record.title}</h1>
			  <p>{detectAndConvertLinks(record.content1)}</p> 
			  {URL && <img className="recordImages" src={URL} alt="Record" />}
			  <p>{detectAndConvertLinks(record.content2)}</p>
			  <p>{detectAndConvertLinks(record.content3)}</p>
			  <p>{detectAndConvertLinks(record.content4)}</p>
			  
			</div>
		);			
	}else if(record.displayStyle == 4 && record.img1 != ""){
		return (
			<div>
			  <h1>{record.title}</h1>
			  <p>{detectAndConvertLinks(record.content1)}</p> 
			  <p>{detectAndConvertLinks(record.content2)}</p>
			  {URL && <img className="recordImages" src={URL} alt="Record" />}
			  <p>{detectAndConvertLinks(record.content3)}</p>
			  <p>{detectAndConvertLinks(record.content4)}</p>
			  
			</div>
		);			
	}else if(record.displayStyle == 5 && record.img1 != ""){
		return (
			<div>
			  <h1>{record.title}</h1>
			  <p>{detectAndConvertLinks(record.content1)}</p> 
			  <p>{detectAndConvertLinks(record.content2)}</p>
			  <p>{detectAndConvertLinks(record.content3)}</p>
			  {URL && <img className="recordImages" src={URL} alt="Record" />}
			  <p>{detectAndConvertLinks(record.content4)}</p>
			  
			</div>
		);			
	}else{
		return (
			<div>
			  <h1>{record.title}</h1>
			  <p>{detectAndConvertLinks(record.content1)}</p>
			  <p>{detectAndConvertLinks(record.content2)}</p>
			  <p>{detectAndConvertLinks(record.content3)}</p>
			  <p>{detectAndConvertLinks(record.content4)}</p>
			</div>
		);
	}
}


export default RecordPage;
