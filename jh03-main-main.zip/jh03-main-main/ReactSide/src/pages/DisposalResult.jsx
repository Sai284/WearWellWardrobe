import { useLocation } from "react-router-dom";
import { Link } from 'react-router-dom';
import { useState, useEffect } from "react";

function DisposalResult() {
    const location = useLocation();
    const answers = location.state?.answers || [];
    console.log("Received answers:", answers);
    const [outcome, setOutcome] = useState(null);

    useEffect(() => {
        let newOutcome = <Link to="/PassOn" className="body-link">Pass It On</Link>
        console.log("Updating outcome based on answers...");
        if (answers[0] == ("Yes")) {
            newOutcome = <div><Link to="/records/16" className="body-link">Pass it On</Link><br /><Link to="/records/15" className="body-link">Sell</Link></div>
        } else if (answers[0] == ("No")) {
            newOutcome = <div><Link to="/records/14" className="body-link">Landfill</Link><br /><Link to="/records/12" className="body-link">Downcycle</Link></div>
        }

        setOutcome(newOutcome);
    }, [answers]);

    return (
        <div>
            <br /><br /><br />
            <p>This link should help you dispose of your clothing properly: {outcome}</p>
        </div>
    )
};

export default DisposalResult;