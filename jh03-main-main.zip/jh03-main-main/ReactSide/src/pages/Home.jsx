import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import React, { useEffect, useState } from 'react';
import logo from '/wwwInfo.jpg';
import '../App.css';
import { useNavigate } from "react-router-dom";
import RecordPage from "./RecordPage";

function Home() {
	
  var [records, setRecords] = useState([]);
  const [showIntro, setShowIntro] = useState(true);
  var [categories, setCategories] = useState([]);
  
  useEffect(() => {
    async function fetchData() {
      try { /*Try to fetch from localhost first */
        let response = await fetch("http://127.0.0.1:8000/api/items/");
        if (!response.ok) throw new Error("Localhost did not respond");
        let data = await response.json();
        setRecords(data);
		
		let catResponse = await fetch("http://127.0.0.1:8000/api/categories/");
		if(!catResponse.ok) throw new Error("Localhost didnt connect for categories");
		let catData = await catResponse.json();
		setCategories(catData);
		
      } catch (error) {
        console.log("Could not connect to localHost. Connecting to Main Site");
		
        try { /*If localhost failed, try python anywhere next */
          let response = await fetch("https://wearwellwardrobe.pythonanywhere.com/api/items/");
          if (!response.ok) throw new Error("Main Site did not respond");
          let data = await response.json();
		  online = true; // Know that its from python anywhere for image fetching
          setRecords(data);

			let catResponse = await fetch("https://wearwellwardrobe.pythonanywhere.com/api/categories/");
			if(!catResponse.ok) throw new Error("Localhost didnt connect for categories");
			let catData = await catResponse.json();
			setCategories(catData);
		  
        } catch (err) { /* both failed */
          console.log("Both API calls failed:", err);
        }
      }
    }
    fetchData();
  }, []);

	
	
	
  const [activeTriangle, setActiveTriangle] = useState(null); // Tracks which triangle is active
  const navigate = useNavigate();

  function handleNavigation(targetPage, triangle) {
    setActiveTriangle(triangle); // Set the active triangle

    setTimeout(() => {
      navigate(targetPage); // Navigate after transition
    }, 200); // Transition duration to match opacity
  }

		
		
  return (
    <div className="home-container">
      <header className="header">
        <h1>Wear Well Wardrobe</h1>
      </header>

      <div className="image-container">
        <img src={logo} className="logo" alt="Logo" />
        <div className="pentagon-container">
          <div
            className={`triangle top ${activeTriangle === "top" ? "active" : ""}`}
            onClick={() => handleNavigation("/access", "top")}
          />
          
          <div
            className={`triangle lease ${activeTriangle === "lease" ? "active" : ""}`}
            onClick={() => handleNavigation("/records/2", "lease")}
          />

          <div
            className={`triangle rent ${activeTriangle === "rent" ? "active" : ""}`}
            onClick={() => handleNavigation("/records/3", "rent")}
          />

          <div
            className={`triangle share ${activeTriangle === "share" ? "active" : ""}`}
            onClick={() => handleNavigation("/records/4", "share")}
          />

          <div
            className={`triangle top-right ${activeTriangle === "top-right" ? "active" : ""}`}
            onClick={() => handleNavigation("/maintain", "top-right")}
          />

          <div
            className={`triangle wash ${activeTriangle === "wash" ? "active" : ""}`}
            onClick={() => handleNavigation("/records/6", "wash")}
          />

          <div
            className={`triangle repair ${activeTriangle === "repair" ? "active" : ""}`}
            onClick={() => handleNavigation("/records/7", "repair")}
          />
          
          <div
            className={`triangle bottom-right ${activeTriangle === "bottom-right" ? "active" : ""}`}
            onClick={() => handleNavigation("/storage", "bottom-right")}
          />

          <div
            className={`triangle clear ${activeTriangle === "clear" ? "active" : ""}`}
            onClick={() => handleNavigation("/records/9", "clear")}  //missing?
          />

          <div
            className={`triangle pest ${activeTriangle === "pest" ? "active" : ""}`}
            onClick={() => handleNavigation("/records/10", "pest")}  //missing?
          />
          
          <div
            className={`triangle bottom-left ${activeTriangle === "bottom-left" ? "active" : ""}`}
            onClick={() => handleNavigation("/adapt", "bottom-left")}
          />

          <div
            className={`triangle upcycle ${activeTriangle === "upcycle" ? "active" : ""}`}
            onClick={() => handleNavigation("/records/13", "upcycle")}
          />

          <div
            className={`triangle downcycle ${activeTriangle === "downcycle" ? "active" : ""}`}
            onClick={() => handleNavigation("/records/12", "downcycle")}
          />
          <div
            className={`triangle top-left ${activeTriangle === "top-left" ? "active" : ""}`}
            onClick={() => handleNavigation("/disposal", "top-left")}
          />
          <div
            className={`triangle donate ${activeTriangle === "donate" ? "active" : ""}`}
            onClick={() => handleNavigation("/records/18", "donate")}
          />
           <div
            className={`triangle pass ${activeTriangle === "pass" ? "active" : ""}`}
            onClick={() => handleNavigation("/records/16", "pass")}
          />
          <div
            className={`triangle sell ${activeTriangle === "sell" ? "active" : ""}`}
            onClick={() => handleNavigation("/records/15", "sell")}
          />
          <div
            className={`triangle landfill-box ${activeTriangle === "landfill-box" ? "active" : ""}`}
            onClick={() => handleNavigation("/landfill", "landfill-box")}
          />
        </div>
      </div>

    </div>
  );
}

export default Home;
