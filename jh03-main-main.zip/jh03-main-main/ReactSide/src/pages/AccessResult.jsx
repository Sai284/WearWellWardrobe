import { useLocation } from "react-router-dom";
import { Link } from 'react-router-dom';
import { useState, useEffect } from "react";

function AccessResult() {
    const location = useLocation();
    const answers = location.state?.answers || [];
    console.log("Received answers:", answers);
    const [outcome, setOutcome] = useState(null);

    useEffect(() => {

        let newOutcome = <Link style={{ color: "blue" }} to="/records/20" className="body-link">Sustainable Shopping</Link>
        console.log("Updating outcome based on answers...");
        if (answers[0] == "No") {
            newOutcome = <Link style={{ color: "blue" }} to="/Adapt" className="body-link">adapt your existing clothes</Link>
        } else if (answers[1] == ("Yes")) {
            newOutcome = <Link style={{ color: "blue" }} to="/records/3" className="body-link">Rent</Link>
        } else if (answers[2] == ("Yes") && answers[3] == ("Yes")) {
            newOutcome = <Link style={{ color: "blue" }} to="/records/18" className="body-link">Charity shopping</Link>
        } else if (answers[2] == ("Yes") && answers[3] == ("No")) {
            newOutcome = <Link style={{ color: "blue" }} to="/records/19" className="body-link">Online second hand shopping</Link>
        }

        setOutcome(newOutcome);
    }, [answers]);

    return (
        <div>
            <br /><br /><br />
            <p>Based on your responses, the best way for you to access the clothing you need is to {outcome}. Click on the link to learn more!</p>
        </div>
    )
};

export default AccessResult;