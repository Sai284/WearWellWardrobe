import React from "react";
import { useState, useEffect } from "react";
import { useLocation, useNavigate, useParams } from 'react-router-dom';

const questions = [
    { question: "Can the item be reworn?", options: ["Yes", "No"] },
];


function DisposalForm() {
    const { questionIndex } = useParams();
    const navigate = useNavigate();
    const location = useLocation();

    const index = parseInt(questionIndex, 10);
    if (isNaN(index) || index < 0 || index >= questions.length) {
        return <h2>Invalid question index.</h2>;
    }

    console.log("Current questionIndex from URL:", questionIndex);
    console.log("Parsed index:", index);

    const [answers, setAnswers] = useState(() => {
        return location.state?.answers || new Array(questions.length).fill(null);
    });


    useEffect(() => {
        console.log("Current answers:", answers);
    }, [answers]);


    const handleNext = (answer) => {

        setAnswers((prevAnswers) => {
            const updatedAnswers = [...answers];
            updatedAnswers[index] = answer;

            console.log("Updated answers before navigation:", updatedAnswers);

            if (index < questions.length - 1) {
                navigate(`/DisposalForm/${index + 1}`, { state: { answers: updatedAnswers } });
            } else {
                navigate("/DisposalResult", { state: { answers: updatedAnswers } });
            }

            return updatedAnswers;
        });
    };

    return (
        <div className="button-container">
            <h2>{questions[index].question}</h2>
            {questions[index].options.map((option, i) => (
                <button key={i}
                    onClick={() => handleNext(option)}>{option}</button>))}
        </div>
    );
}

export default DisposalForm;