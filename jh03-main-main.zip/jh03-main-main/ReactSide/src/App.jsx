import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import React, { useEffect, useState } from 'react';
import Navbar from './components/Navbar';
import BurgerMenu from './components/BurgerMenu';
import Home from './pages/Home';
import Help from './pages/Help';
import Access from './pages/Access';
import Maintain from './pages/Maintain';
import Storage from './pages/Storage';
import Adapt from './pages/Adapt';
import Disposal from './pages/Disposal';
import './ImageStyling.css';
import Question from "./pages/Question";
import DisposalResult from "./pages/DisposalResult";
import DisposalForm from "./pages/DisposalForm";
import Result from "./pages/Result";
import Intro from './components/Intro';
import AccessResult from "./pages/AccessResult";
import AccessForm from "./pages/AccessForm";
import RecordPage from "./pages/RecordPage";
import Landfill from './pages/Landfill';

// this varible is set when the first call is done to ensure that the image is from the right place
var online = false;




export default function App() {
  var [records, setRecords] = useState([]);
  const [showIntro, setShowIntro] = useState(true);
  var [categories, setCategories] = useState([]);
  
  useEffect(() => {
    async function fetchData() {
      try { /*Try to fetch from localhost first */
        let response = await fetch("http://127.0.0.1:8000/api/items/");
        if (!response.ok) throw new Error("Localhost did not respond");
        let data = await response.json();
        setRecords(data);
		
		let catResponse = await fetch("http://127.0.0.1:8000/api/categories/");
		if(!catResponse.ok) throw new Error("Localhost didnt connect for categories");
		let catData = await catResponse.json();
		setCategories(catData);
		
      } catch (error) {
        console.log("Could not connect to localHost. Connecting to Main Site");
		
        try { /*If localhost failed, try python anywhere next */
          let response = await fetch("https://wearwellwardrobe.pythonanywhere.com/api/items/");
          if (!response.ok) throw new Error("Main Site did not respond");
          let data = await response.json();
		  online = true; // Know that its from python anywhere for image fetching
          setRecords(data);

			let catResponse = await fetch("https://wearwellwardrobe.pythonanywhere.com/api/categories/");
			if(!catResponse.ok) throw new Error("Localhost didnt connect for categories");
			let catData = await catResponse.json();
			setCategories(catData);
		  
        } catch (err) { /* both failed */
          console.log("Both API calls failed:", err);
        }
      }
    }
    fetchData();
  }, []);


  useEffect(() => {
    // Hide the intro after 2 seconds
    const timer = setTimeout(() => {
      setShowIntro(false);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  if (!records.length) {
    // Just got it so intro has seamless transition from loading, easier I think
    return <img src="\WearWellWardrobeLoading.png" alt="Intro" className="IntroIMG" />;
  }

  const renderRecordPage = (page_id) => {
    const record = records.find((r) => r.page_id === page_id);
    return record ? <RecordPage record={record} /> : <h1>Record Not Found</h1>;
  };

  return (
    <Router>
      {showIntro && <Intro />} 
      {!showIntro && ( 
        <>
          <BurgerMenu />
          <Navbar />
          <Link to="/help">
            <img src="/help-252-512.png" alt="Help" className="help-icon" />
          </Link>

          <div id="lilguy">
            <Link to="/">
              <img src="/lilGuyNav.png" alt="Banner" className="lilguy" />
            </Link>
          </div>

	  
	  <div id="mainContainer">

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/help" element={<Help />} />
        <Route path="/access" element={<Access />} />        
        <Route path="/maintain" element={<Maintain />} />
        <Route path="/storage" element={<Storage />} />        
        <Route path="/adapt" element={<Adapt />} />
        <Route path="/Disposal" element={<Disposal />} />
        <Route path="/question/:questionIndex" element={<Question />} />
        <Route path="/result" element={<Result />} />
        <Route path="/landfill" element={<Landfill />} />
        <Route path="/DisposalForm/:questionIndex" element={<DisposalForm />} />
        <Route path="/DisposalResult" element={<DisposalResult />} />
        <Route path="/AccessForm/:questionIndex" element={<AccessForm />} />
        <Route path="/AccessResult" element={<AccessResult />} />
		
        {records.map((record) => (
          <Route key={record.page_id} path={`/records/${record.page_id}`} element={renderRecordPage(record.page_id)} />
        ))}
      </Routes>
	  </div>
      </>
      )}
    </Router>
  );
}
