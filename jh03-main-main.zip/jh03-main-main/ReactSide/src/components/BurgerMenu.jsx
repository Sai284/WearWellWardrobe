import React, { useEffect, useState } from 'react';
import { Link } from "react-router-dom";
import "./BurgerMenu.css";

function BurgerMenu() {
  var online = false;

  var [records, setRecords] = useState([]);
  const [showIntro, setShowIntro] = useState(true);
  var [categories, setCategories] = useState([]);
  
  useEffect(() => {
    async function fetchData() {
      try { /*Try to fetch from localhost first */
        let response = await fetch("http://127.0.0.1:8000/api/items/");
        if (!response.ok) throw new Error("Localhost did not respond");
        let data = await response.json();
        setRecords(data);
		
		let catResponse = await fetch("http://127.0.0.1:8000/api/categories/");
		if(!catResponse.ok) throw new Error("Localhost didnt connect for categories");
		let catData = await catResponse.json();
		setCategories(catData);
		
      } catch (error) {
        console.log("Could not connect to localHost. Connecting to Main Site");
		
        try { /*If localhost failed, try python anywhere next */
          let response = await fetch("https://wearwellwardrobe.pythonanywhere.com/api/items/");
          if (!response.ok) throw new Error("Main Site did not respond");
          let data = await response.json();
		  online = true; // Know that its from python anywhere for image fetching
          setRecords(data);

			let catResponse = await fetch("https://wearwellwardrobe.pythonanywhere.com/api/categories/");
			if(!catResponse.ok) throw new Error("Localhost didnt connect for categories");
			let catData = await catResponse.json();
			setCategories(catData);
		  
        } catch (err) { /* both failed */
          console.log("Both API calls failed:", err);
        }
      }
    }
    fetchData();
  }, []);

  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = (event) => {
    event.stopPropagation();
    setIsOpen(!isOpen);
  };

  const closeMenu = () => {
    setIsOpen(false);
  };

  return (
    <>
      {isOpen && <div className="menu-overlay" onClick={closeMenu}></div>}

      <div className="burger-menu">
        <div className="burger-icon" onClick={toggleMenu}>
          <div className={`burger-line ${isOpen ? "open" : ""}`}></div>
          <div className={`burger-line ${isOpen ? "open" : ""}`}></div>
          <div className={`burger-line ${isOpen ? "open" : ""}`}></div>
        </div>

        <div className={`side-menu ${isOpen ? "show" : ""}`} onClick={(e) => e.stopPropagation()}>
          <h2 className="menu-title">Main Pages</h2> {/* Title added */}
          <Link to="/access" className="menu-link" onClick={closeMenu}>{categories.find(item => item.ID === 1)?.name || "Not Found"} </Link>
          <Link to="/maintain" className="menu-link" onClick={closeMenu}>{categories.find(item => item.ID === 3)?.name || "Not Found"}</Link>
          <Link to="/storage" className="menu-link" onClick={closeMenu}>{categories.find(item => item.ID === 2)?.name || "Not Found"}</Link>
          <Link to="/adapt" className="menu-link" onClick={closeMenu}>{categories.find(item => item.ID === 4)?.name || "Not Found"}</Link>
          <Link to="/disposal" className="menu-link" onClick={closeMenu}>{categories.find(item => item.ID === 5)?.name || "Not Found"}</Link>
        </div>
      </div>
    </>
  );
}

export default BurgerMenu;

