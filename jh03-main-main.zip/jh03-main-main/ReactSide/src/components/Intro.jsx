import React, { useEffect, useState } from "react";
import './Intro.css';

function Intro() {
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setVisible(false); // Hide image after 2 seconds
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className={`intro-container ${visible ? "" : "fade-out"}`}>
      {visible && <img src="\WearWellWardrobeLoading.png" alt="Intro" className="IntroIMG" />}
    </div>
  );
}

export default Intro;
