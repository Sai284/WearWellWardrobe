import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import './NavBar.css'; 

function Navbar() {
  const location = useLocation();
  const [navColor, setNavColor] = useState(''); 

  useEffect(() => {
    const getNavColorClass = () => {
      const path = location.pathname;
      const match = path.match(/\/records\/(\d+)/);
      const id = match ? parseInt(match[1], 10) : null;

      if (id) {
        if ([1, 2, 3, 4].includes(id)) return 'access';
        if ([17].includes(id)) return 'landfill';
        if ([5, 6, 7].includes(id)) return 'maintain';
        if ([8, 9, 10].includes(id)) return 'storage';
        if ([11, 12, 13].includes(id)) return 'adapt';
        if ([14, 15, 16, 18].includes(id)) return 'disposal';
      } /*Since it's hardcoded this works, just remeber this when changing it up*/

      if (path === '/' || path === '/about') {
        return 'green'; // Green color for Home page
      } else if (path.includes('help')) {
        return 'help'; 
      } else if (path.includes('access')) {
        return 'access'; 
      } else if (path.includes('maintain')) {
        return 'maintain';
      } else if (path.includes('storage')) {
        return 'storage'; 
      } else if (path.includes('adapt')) {
        return 'adapt';
      } else if (path.includes('disposal')) {
        return 'disposal'; 
      } else if (path.includes('landfill')) {
        return 'landfill'; 
      }

      return navColor; // Retain the last applied color if no match
    };

    // Update the state with the current color
    setNavColor(getNavColorClass());
  }, [location]); // Re-run effect when location changes

  return (
    <div id="NavBar" className={navColor}>
    </div> //keeping nav bar blank, it's meant to be a plain block
  );
}

export default Navbar;
