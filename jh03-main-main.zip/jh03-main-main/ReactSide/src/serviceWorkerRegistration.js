// src/serviceWorkerRegistration.js

// Function to register the service worker
export function register(config) {
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', () => {
            const swUrl = `${process.env.PUBLIC_URL}/service-worker.js`; // Path to the service worker script

            navigator.serviceWorker
                .register(swUrl)
                .then((registration) => {
                    registration.onupdatefound = () => {
                        const installingWorker = registration.installing;
                        if (installingWorker) {
                            installingWorker.onstatechange = () => {
                                if (installingWorker.state === 'installed') {
                                    if (navigator.serviceWorker.controller) {
                                        // New content available, notify the user to update
                                        if (config && config.onUpdate) {
                                            config.onUpdate(registration);
                                        }
                                    }
                                }
                            };
                        }
                    };
                })
                .catch((error) => console.error('Error during service worker registration:', error));
        });
    }
}

// Function to unregister the service worker
export function unregister() {
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.ready
            .then((registration) => {
                registration.unregister();
            })
            .catch((error) => console.error('Error during service worker unregistration:', error));
    }
}
